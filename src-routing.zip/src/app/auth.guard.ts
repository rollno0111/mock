import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) { }

  canActivate() {
    let today = new Date();
    if (today.getHours() >= 9 && today.getHours() <= 17) {
      this.router.navigate(['/login']);
      return false;
    } else {
      return true;
    }
    // if time is between 9AM to 5pm DONT ALLOW THE ACCESS - redirect to login page & 
    // REDIRECT TO LOGIN PAGE ELSE SHOW THE EMPLOYEELIST PAGE 
  }

}