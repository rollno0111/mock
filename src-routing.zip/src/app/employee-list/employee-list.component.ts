import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private router: Router) { }

  empIdArray = [
    { empId: 1, empName: "John" },
    { empId: 2, empName: "Jack" },
    { empId: 3, empName: "Jill" },
    { empId: 4, empName: "Steve" }
  ];

  ngOnInit(): void { }

  fun(emp) {
    // this.router ==> navigate()
    this.router.navigate(['/employee-details', emp.empId, emp.empName]);
  }
}

// Data exchange between component is a must in assessment 
// Routing - routerlink, router navigate()
// Input, Output, 
// Services
