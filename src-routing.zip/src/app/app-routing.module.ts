import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';

// URL ==> http://localhost:4200/ 

// '' should be a prefix of the URL ("/login"),("/hello")

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  // { path: '', component: LoginComponent },
  {
    path: 'login',
    component: LoginComponent
  },
  { path: 'register', component: RegisterComponent, canActivate: [AuthGuard] },
  { path: 'employee', component: EmployeeListComponent, canActivate: [AuthGuard] },
  { path: 'employee-details/:empId/:empName', component: EmployeeDetailsComponent },
  { path: '**', component: PageNotFoundComponent }
];

// /employee-details/1
// /employee-details/2 ==> string
// /employee-details/abc
// /employee-details/true
// /employee-details ==> does not loas empdetails comp

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

