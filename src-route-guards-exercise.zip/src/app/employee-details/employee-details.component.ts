import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router'; // line 1

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  constructor(private aRoute: ActivatedRoute) { } // line 2

  employeeId = ""
  employeeName = "";

  ngOnInit(): void {
    this.aRoute.params.subscribe(
      (param) => {
        this.employeeId = param.empId,
          this.employeeName = param.empName
      }
    )
  }
}
