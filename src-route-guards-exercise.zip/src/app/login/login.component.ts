import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DemoService } from '../demo.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName = "";
  password = "";
  errorMessage = "";

  constructor(private ds: DemoService, private router: Router) { }

  ngOnInit(): void {
  }

  loginUser(userName, password) {
    if (userName == 'admin' && password == 'admin@123') {
      this.ds.password = 'admin@123';
      this.ds.userName = 'admin';
      this.router.navigate(['/employee'])
    } else {
      this.errorMessage = "Incorrect Credentials";
    }
  }

}
