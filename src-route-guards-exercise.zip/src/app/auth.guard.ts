import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { DemoService } from './demo.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private ds: DemoService) { }

  canActivate() {
    let userName = this.ds.userName;
    let password = this.ds.password;
    if (userName == 'admin' && password == 'admin@123') {
      return true;
    } else {
      this.router.navigate(['/pagenotfound']);
      return false;
    }
    // if time is between 9AM to 5pm DONT ALLOW THE ACCESS - redirect to login page & 
    // REDIRECT TO LOGIN PAGE ELSE SHOW THE EMPLOYEELIST PAGE 
  }
}